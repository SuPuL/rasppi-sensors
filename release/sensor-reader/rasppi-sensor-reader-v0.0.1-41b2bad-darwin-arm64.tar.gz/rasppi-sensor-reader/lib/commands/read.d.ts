import { Command } from '@oclif/core';
interface Context {
    mock: boolean;
    interval: number;
}
export default class Read extends Command {
    static description: string;
    static examples: string[];
    static flags: {
        interval: import("@oclif/core/lib/interfaces").OptionFlag<number>;
        mock: import("@oclif/core/lib/interfaces").BooleanFlag<boolean>;
    };
    static args: never[];
    run(): Promise<void>;
    readSensorIds: ({ mock }: Context) => Promise<import(".prisma/client").SensorInfo[]>;
    startReadLoop: ({ mock, interval }: Context) => Promise<void>;
}
export {};
